const blogTable=require('../models/blog')

exports.blogform=(req,res)=>{
    const loginName=req.session.login
    let mess=''
    res.render('users/blogform.ejs',{loginName,mess})
}

exports.newblog=(req,res)=>{
    const{title,desc}=req.body
    let mess=''
    const loginName=req.session.login
    try{
        if(!title || !desc){
            throw new Error("All fileds are complusory!!")
        }
    
    const newBlog=new blogTable({title:title,desc:desc,username:loginName})
    newBlog.save()
    mess='Successfuly Blog has been Craeted!!'
    }catch(error){
        mess=error.message
    }
    res.render('users/blogform.ejs',{loginName,mess})
}

exports.myblog=async(req,res)=>{
    const loginName=req.session.login
    const data=await blogTable.find({username:loginName})
   res.render('users/myblog.ejs',{loginName,data})
}

exports.allblogs=async(req,res)=>{
    const loginName=req.session.login
    const data=await blogTable.find()
    res.render('users/allblogs',{loginName,data})
}

exports.contactdeatil=(req,res)=>{
    const loginName=req.session.login
    res.render('users/contactdetails.ejs',{loginName})
}