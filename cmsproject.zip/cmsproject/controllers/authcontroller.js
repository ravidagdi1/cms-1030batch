const authTable = require('../models/auth')
const transporter = require('../helper/smptemail')
const bcrypt=require('bcrypt')


exports.createaccountform = (req, res) => {
    let mess=''
    res.render('createaccountform.ejs',{mess})
}

exports.createaccount = async (req, res) => {
    let mess = ''
    const { fname, lname, email, pass } = req.body
    try {
        if (!fname || !lname || !email || !pass) {
            throw new Error("all fileds are complusory!!")
        }
        const emailcheck = await authTable.findOne({ email: email })
        if (!emailcheck) {
            const convertedpass=await bcrypt.hash(pass,10)
            const newAccount = new authTable({ firstName: fname, lastName: lname, email: email, password: convertedpass })
            const output = await newAccount.save()
            await transporter.sendMail({
                from: 'rtestexpress@gmail.com',
                to: email,
                subject: 'Activation Link: xyz website',
                html: `<a href=http://localhost:5000/activationlink/${output.id} >Activation Link</a>`
            })
            mess = 'Account has been Created successfully! Please check your email to activate the account!!'
        } else {
            throw new Error('Email is already Registerted with us!!!')

        }
    } catch (error) {
        mess = error.message
    }
    res.render('createaccountform.ejs', { mess })
}

exports.activationlink = async (req, res) => {
    let mess = ''
    try {
        const id = req.params.id
        await authTable.findByIdAndUpdate(id, { status: 'active' })
        mess = "You account has been activated! Click on below link to login again!!"
        res.render('activationmessage.ejs', { mess })
    } catch (error) {
        console.log(error.message)
    }

}

exports.loginform=(req,res)=>{
    let mess=''
    res.render('login.ejs',{mess})
}


exports.logincheck=async(req,res)=>{
    let mess=''
    const{email,pass}=req.body
    try{
    const emailcheck=await authTable.findOne({email:email})
    if(emailcheck){
        let comparepass=await bcrypt.compare(pass,emailcheck.password)
            if(comparepass){
            if(emailcheck.status=='active'){
                req.session.isAuth=true
                req.session.login=email
                req.session.payment=emailcheck.paymentStatus
                req.session.role=emailcheck.role
                req.session.userid=emailcheck.id
            res.redirect('/allblogs')
            }else{
                throw new Error("Your account is suspended.Please chekc your email for activation Link")
            }
        }else{
            throw new Error('Wrong credentails')
            
        }

    }else{
        throw new Error('Wrong credentails')

    }
}catch(error){
    mess=error.message
    res.render('login.ejs',{mess})
}
    }


exports.forgetpassform=(req,res)=>{
    let mess=''
    res.render('forgetpassform.ejs',{mess})
}


exports.forgetpasswordemaillink=async(req,res)=>{
    const {email}=req.body
    let mess=''
    try{
    const emailcheck=await authTable.findOne({email:email})
    if(!emailcheck){
        throw new Error("Email not found!")
    }else{
        await transporter.sendMail({
            from:'rtestexpress@gmail.com',
            to:email,
            subject:'Forget Pasword Link: xyz.com',
            html:`<a href=http://localhost:5000/forgetpassformuser/${emailcheck.id}>Click link for new Passsword</a>`
        })
    }
    mess="Forget Link has been sent to your email Id!!"
}catch(error){
    mess=error.message
}
res.render('forgetpassform.ejs',{mess})
}


exports.forgetpassworduserform=(req,res)=>{
    let mess=''
    res.render('forgetpassformuser.ejs',{mess})
}

exports.forgetpassworduser=async(req,res)=>{
    const{npass,cpass}=req.body
    let mess=''
    try{
        if(!npass || !cpass){
            throw new Error("All fileds are complusory!!")
        }
    const id=req.params.id
    let convertedpass=await bcrypt.hash(npass,10)
    await authTable.findByIdAndUpdate(id,{password:convertedpass})
    res.render('forgetmessage.ejs')
    }catch(error){
        mess=error.message
        res.render('forgetpassformuser.ejs',{mess})
    }
}


exports.allusers=async(req,res)=>{
    const loginName=req.session.login
    const data=await authTable.find()
    res.render('admin/users.ejs',{loginName,data})
}

exports.rolechange=async(req,res)=>{
    const id=req.params.id
    const currentRole=req.params.role
    let newRole=null
    if(currentRole=='user'){
        newRole='admin'
    }else{
        newRole='user'
    }
    await authTable.findByIdAndUpdate(id,{role:newRole})
    res.redirect('/admin/users')
}

exports.statuschange=async(req,res)=>{
    const id=req.params.id
    const currentStatus=req.params.status
    let newstatus=null
    if(currentStatus=='active'){
        newstatus='suspended'
    }else{
        newstatus='active'
    }
    await authTable.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/users')
}

exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}

exports.changepassform=(req,res)=>{
    const loginName=req.session.login
    let mess=''
    res.render('users/changepassform.ejs',{loginName,mess})
}

exports.changepasword=async(req,res)=>{
    const loginName=req.session.login
    let mess=''
    const{cpass,newpass,confirmpass}=req.body
    const userid=req.session.userid
    try{
   if(!cpass || !newpass || !confirmpass){
    throw new Error("all fileds are complusory!!")
   }
   const data=await authTable.findById(userid)
   const passcompare= await bcrypt.compare(cpass,data.password)
   if(!passcompare){
    throw new Error("Current Password Not matched")
   }
   if(newpass !==confirmpass){
    throw new Error("Password not matched!!")
   }
   const bpass=await bcrypt.hash(newpass,10)
   await authTable.findByIdAndUpdate(userid,{password:bpass})
   mess='Password has been Changed!!'
   function handlesessionout(){
    req.session.destroy()
   }
   setTimeout(handlesessionout,1000)
    }catch(error){
        mess=error.message
    }
    
    res.render('users/changepassform.ejs',{loginName,mess})


}