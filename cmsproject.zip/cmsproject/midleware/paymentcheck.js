function handlepayemntcheck (req,res,next){
    if(req.session.payment=='paid'){
        next()
    }else{
        res.render('users/paymentmessage.ejs')
    }
}

module.exports=handlepayemntcheck