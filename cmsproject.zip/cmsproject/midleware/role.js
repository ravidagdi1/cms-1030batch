function handleRole(req,res,next){
    if(req.session.role!=='admin'){
        next()
    }else{
        res.redirect('/admin/dashboard')
    }

}

module.exports=handleRole