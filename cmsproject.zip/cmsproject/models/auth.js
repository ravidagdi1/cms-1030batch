const mongoose = require('mongoose')



const authSchema = mongoose.Schema({
    firstName: {
        type: String,
        required: true,
    },
    lastName: {
        type: String,
        required: true,
    },

    email: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        required: true,
        default: 'suspended'
    },
    createdDate: {
        type: Date,
        required: true,
        default: new Date()
    },
    role:{
        type:String,
        required:true,
        default:'user'
    }

})


module.exports=mongoose.model('auth',authSchema)