const mongoose = require('mongoose')



const blogSchema = mongoose.Schema({
    title: {
        type: String,
        required: true,
    },
    desc: {
        type: String,
        required: true,
    },

    username: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        required: true,
        default: 'active'
    },
    createdDate: {
        type: Date,
        required: true,
        default: new Date()
    },
    paymentStatus:{
        type:String,
        default:'free',
        required:true
    }
    

})


module.exports=mongoose.model('blog',blogSchema)