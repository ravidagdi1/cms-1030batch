const express=require('express')
const app=express()
require('dotenv').config()
app.use(express.urlencoded({extended:false}))
const userRouter=require('./routers/usersRouter')
const adminRouter=require('./routers/admin')
require('./dbconnection/dbconnection')
const session=require('express-session')


app.use(session({
    secret:process.env.SECRET,
    resave:false,
    saveUninitialized:false
}))
app.use(userRouter)
app.use('/admin',adminRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{console.log(`Server is running on port ${process.env.PORT}`)})




