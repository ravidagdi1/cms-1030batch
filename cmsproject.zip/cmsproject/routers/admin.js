const router=require('express').Router()
const handlesession=require('../midleware/sessioncheck')
const authc=require('../controllers/authcontroller')
const blogc=require('../controllers/blogcontroller')


router.get('/dashboard',handlesession,(req,res)=>{
    const loginName=req.session.login
    res.render('admin/dashboard.ejs',{loginName})
})

router.get('/users',handlesession,authc.allusers)
router.get('/userrolechange/:id/:role',authc.rolechange)
router.get('/userstatuschange/:id/:status',authc.statuschange)
router.get('/logout',handlesession,authc.logout)





module.exports=router