const router=require('express').Router()
const authc=require('../controllers/authcontroller')
const handlesessioncheck=require('../midleware/sessioncheck')
const handleRole=require('../midleware/role')
const blogc=require('../controllers/blogcontroller')
const handlepayemntcheck=require('../midleware/paymentcheck')



router.get('/',authc.loginform)
router.post('/',authc.logincheck)

router.get('/createaccount',authc.createaccountform)
router.post('/createaccount',authc.createaccount)

router.get('/activationlink/:id',authc.activationlink)

//forget password router
router.get('/forgetpassform',authc.forgetpassform)
router.post('/forgetpassform',authc.forgetpasswordemaillink)

//show foregt form to user
router.get('/forgetpassformuser/:id',authc.forgetpassworduserform)
router.post('/forgetpassformuser/:id',authc.forgetpassworduser)

//users

router.get('/users',handlesessioncheck,handleRole,(req,res)=>{
    const loginName=req.session.login
   res.render('users/users.ejs',{loginName})
})


router.get('/myblog',handlesessioncheck,handleRole,blogc.myblog)

router.get('/addblog',handlesessioncheck,blogc.blogform)
router.post('/addblog',blogc.newblog)

router.get('/allblogs',handlesessioncheck,handleRole,blogc.allblogs)

router.get('/contactdetails',handlesessioncheck,handlepayemntcheck,blogc.contactdeatil)

router.get('/changepassform',handlesessioncheck,authc.changepassform)

router.post('/changepassform',authc.changepasword)

















module.exports=router